import copy
import unittest
from unittest.mock import patch

from blockchain import Blockchain, Wallet
from p2p import PeerManager, PeerError, normalize_peer_url


class PeerManagerTests(unittest.TestCase):
    def setUp(self):
        self.wallet = Wallet()
        self.chain = Blockchain(
            difficulty=1,
            initial_balances={self.wallet.get_address(): 100},
            transaction_fee=1,
        )
        self.manager = PeerManager(
            self.chain, chain_file="unused-globalcoin-test.json",
            auth_token="test-token"
        )

    def test_register_and_list_peer(self):
        peer = self.manager.register_peer("http://127.0.0.1:8001")
        self.assertEqual(peer["url"], "http://127.0.0.1:8001")
        self.assertEqual(len(self.manager.list_peers()), 1)

    def test_reject_plain_http_remote_peer(self):
        with self.assertRaises(PeerError):
            normalize_peer_url("http://example.com:8000")

    def test_reject_private_ip(self):
        with self.assertRaises(PeerError):
            normalize_peer_url("http://192.168.1.10:8000")

    def test_reject_malformed_url(self):
        with self.assertRaises(PeerError):
            normalize_peer_url("not-a-url")

    def test_reject_unknown_peer_for_sync(self):
        with self.assertRaises(PeerError):
            self.manager.sync_from_peer("http://127.0.0.1:8001")

    def test_validate_remote_chain(self):
        candidate = self.manager._validated_remote_chain(
            self.manager.export_chain()
        )
        self.assertTrue(candidate.is_chain_valid())

    def test_reject_wrong_version(self):
        payload = self.manager.export_chain()
        payload["version"] = "wrong"
        with self.assertRaises(PeerError):
            self.manager._validated_remote_chain(payload)

    def test_reject_tampered_chain(self):
        payload = copy.deepcopy(self.manager.export_chain())
        payload["chain"][0]["nonce"] += 1
        with self.assertRaises(PeerError):
            self.manager._validated_remote_chain(payload)

    def test_reject_invalid_consensus(self):
        payload = self.manager.export_chain()
        payload["difficulty"] = "easy"
        with self.assertRaises(PeerError):
            self.manager._validated_remote_chain(payload)

    @patch("p2p.urlopen", side_effect=OSError("network down"))
    def test_network_error_is_safe(self, _mock):
        self.manager.register_peer("http://127.0.0.1:8001")
        with self.assertRaises(PeerError):
            self.manager.check_peer("http://127.0.0.1:8001")

    def test_sync_accepts_longer_valid_same_genesis_chain_and_clears_pending(self):
        self.chain.add_transaction(
            self.wallet, Wallet().get_address(), 5
        )
        # Remote chain is copied from the exact local genesis, then extended.
        remote = Blockchain(
            difficulty=1,
            initial_balances={self.wallet.get_address(): 100},
            transaction_fee=1,
        )
        remote.chain = copy.deepcopy(self.chain.chain)
        remote.pending_transactions = []
        remote.mine_pending_transactions(self.wallet.get_address())
        payload = {
            "version": "GLOBALCOIN VERSION 5",
            "difficulty": remote.difficulty,
            "transaction_fee": remote.transaction_fee,
            "chain": remote.chain,
        }
        peer_url = "http://127.0.0.1:8001"
        self.manager.register_peer(peer_url)
        with patch.object(self.manager, "_request_json", return_value=payload), \
             patch("p2p.save_blockchain"):
            result = self.manager.sync_from_peer(peer_url)
        self.assertTrue(result["accepted"])
        self.assertEqual(len(self.chain.chain), 2)
        self.assertEqual(self.chain.pending_transactions, [])
        self.assertEqual(result["discarded_pending_transactions"], 1)


if __name__ == "__main__":
    unittest.main()
