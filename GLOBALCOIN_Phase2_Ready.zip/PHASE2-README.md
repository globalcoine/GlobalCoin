# GLOBALCOIN — Phase 2 P2P integration (prepared)

## Files in this package
- `p2p.py` — peer registration, peer URL checks, chain export and validated synchronization.
- `node.py` — local HTTP node API with bearer-token protection on every POST route.
- `test_p2p.py` — P2P unit tests, including longer-chain synchronization and pending-transaction clearing.

## Do not replace these existing files
Keep your current `blockchain.py` (GLOBALCOIN Version 5) and `storage.py`.
This package imports their existing public interfaces.

## Install in GitHub Codespaces
1. Download and extract this ZIP.
2. Copy `p2p.py`, `node.py`, and `test_p2p.py` into the same repository folder as `blockchain.py` and `storage.py`.
3. Keep a backup of your current `node.py` before replacing it.
4. Do not upload or replace `blockchain.py` or `storage.py` from this package.

## Run tests
```bash
python -m pip install -r requirements.txt
python -m unittest -v test_blockchain.py
python -m unittest -v test_p2p.py
```

The original `test_blockchain.py` must already exist in the repository. It was not included in the supplied Phase 2 ZIP and has not been independently reviewed here.

## Start a local node
Linux/macOS/Codespaces:
```bash
export GLOBALCOIN_NODE_TOKEN="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
python node.py
```

The built-in server refuses to start without a token and binds only to loopback by default.
All POST routes (`/peers`, `/sync`, `/mine`, `/transaction`) require the bearer token.
The legacy `/transaction` route also remains loopback-only because it accepts a private key.

For local API calls, use:
```bash
curl -H "Authorization: Bearer $GLOBALCOIN_NODE_TOKEN" http://127.0.0.1:8000/status
```

## Peer authentication
This MVP uses one shared bearer token for peers in the same trusted test network. Configure the same `GLOBALCOIN_NODE_TOKEN` on both local test nodes. Do not use this prototype on the public internet. Remote deployment needs a properly configured HTTPS reverse proxy, firewall rules, peer-specific credentials, and additional security review.

## Synchronization behavior
A remote chain is accepted only if:
- the software version and consensus parameters match;
- the full chain passes `Blockchain.is_chain_valid()`;
- the genesis hash matches;
- the remote chain is strictly longer.

After successful synchronization, pending local transactions are cleared because their validity may have changed against the newly accepted chain. The response reports how many were discarded.

## Scope limitation
Phase 2 provides peer registration and validated chain synchronization. It does not broadcast signed transactions or implement production-grade distributed consensus, Sybil resistance, peer-specific authorization, or fork-choice beyond longest-valid-chain selection.
