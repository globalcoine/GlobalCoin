"""GLOBALCOIN Phase 2 node API.

Local test:
    export GLOBALCOIN_NODE_TOKEN="<long-random-secret>"
    python node.py

The built-in HTTP server is intended for local testing only. Do not expose it
directly to the public internet. Remote nodes require HTTPS termination,
firewalling, and trusted peers.
"""
import hmac
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from blockchain import Blockchain, Wallet
from storage import save_blockchain, load_blockchain
from p2p import PeerManager, PeerError

CHAIN_FILE = os.environ.get("GLOBALCOIN_CHAIN_FILE", "globalcoin_chain.json")
HOST = os.environ.get("GLOBALCOIN_HOST", "127.0.0.1")
PORT = int(os.environ.get("GLOBALCOIN_PORT", "8000"))
blockchain_lock = threading.RLock()


def get_blockchain():
    try:
        return load_blockchain(CHAIN_FILE)
    except FileNotFoundError:
        chain = Blockchain()
        save_blockchain(chain, CHAIN_FILE)
        return chain


blockchain = get_blockchain()
peer_manager = PeerManager(
    blockchain,
    chain_file=CHAIN_FILE,
    auth_token=os.environ.get("GLOBALCOIN_NODE_TOKEN", ""),
)


class GlobalCoinHandler(BaseHTTPRequestHandler):
    def send_json(self, status, data):
        body = json.dumps(data, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Invalid Content-Length") from exc
        if length < 1 or length > 10000:
            raise ValueError("Request body must be between 1 and 10000 bytes")
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError("Invalid JSON body") from exc
        if not isinstance(data, dict):
            raise ValueError("JSON body must be an object")
        return data

    def authorized(self):
        token = peer_manager.auth_token
        if not token:
            return False
        supplied = self.headers.get("Authorization", "")
        return hmac.compare_digest(supplied, "Bearer " + token)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        with blockchain_lock:
            if path == "/status":
                self.send_json(200, {
                    "name": "GLOBALCOIN",
                    "version": "5",
                    "blocks": len(blockchain.chain),
                    "difficulty": blockchain.difficulty,
                    "total_supply": blockchain.get_total_supply(),
                    "max_supply": 21000000,
                    "pending_transactions": len(blockchain.pending_transactions),
                    "valid": blockchain.is_chain_valid(),
                })
            elif path == "/chain":
                self.send_json(200, {"chain": blockchain.chain})
            elif path == "/pending":
                self.send_json(200, {
                    "pending_transactions": blockchain.pending_transactions
                })
            elif path == "/balance":
                address = parse_qs(parsed.query).get("address", [""])[0]
                try:
                    self.send_json(200, {
                        "address": address,
                        "balance": blockchain.get_balance(address),
                    })
                except (ValueError, TypeError):
                    self.send_json(400, {"error": "Invalid address"})
            elif path == "/peers":
                if not self.authorized():
                    self.send_json(401, {"error": "Unauthorized"})
                else:
                    self.send_json(200, {"peers": peer_manager.list_peers()})
            elif path == "/peer/chain":
                if not self.authorized():
                    self.send_json(401, {"error": "Unauthorized"})
                else:
                    self.send_json(200, peer_manager.export_chain())
            else:
                self.send_json(404, {"error": "Not found"})

    def do_POST(self):
        path = urlparse(self.path).path
        # All POST operations mutate state or expose sensitive functionality.
        # Require a configured bearer token for every POST endpoint.
        if not self.authorized():
            self.send_json(401, {"error": "Unauthorized"})
            return

        try:
            data = self.read_json()
            with blockchain_lock:
                if path == "/peers":
                    peer = peer_manager.register_peer(data.get("url"))
                    self.send_json(201, {"peer": peer})
                elif path == "/sync":
                    url = data.get("url")
                    if not isinstance(url, str):
                        raise ValueError("url is required")
                    result = peer_manager.sync_from_peer(url)
                    self.send_json(200, result)
                elif path == "/mine":
                    miner_address = data.get("miner_address")
                    if not isinstance(miner_address, str):
                        raise ValueError("miner_address is required")
                    block = blockchain.mine_pending_transactions(miner_address)
                    save_blockchain(blockchain, CHAIN_FILE)
                    self.send_json(200, {"block": block})
                elif path == "/transaction":
                    # This legacy endpoint accepts a private key. Keep it
                    # loopback-only even though bearer authentication is used.
                    if self.client_address[0] not in ("127.0.0.1", "::1"):
                        self.send_json(403, {
                            "error": "Private-key transaction endpoint is local-only"
                        })
                        return
                    private_key = data.get("private_key")
                    if not isinstance(private_key, str):
                        raise ValueError("private_key is required")
                    wallet = Wallet.from_private_key(bytes.fromhex(private_key))
                    tx_id = blockchain.add_transaction(
                        wallet, data.get("recipient"),
                        data.get("amount"), data.get("fee")
                    )
                    save_blockchain(blockchain, CHAIN_FILE)
                    self.send_json(201, {"transaction_id": tx_id})
                else:
                    self.send_json(404, {"error": "Not found"})
        except (ValueError, TypeError, json.JSONDecodeError, PeerError) as exc:
            self.send_json(400, {"error": str(exc)})
        except Exception:
            self.send_json(500, {"error": "Internal server error"})

    def log_message(self, fmt, *args):
        print("[GLOBALCOIN]", fmt % args)


if __name__ == "__main__":
    if not os.environ.get("GLOBALCOIN_NODE_TOKEN"):
        print("ERROR: Set GLOBALCOIN_NODE_TOKEN before starting the node.")
        raise SystemExit(1)
    if HOST not in ("127.0.0.1", "::1", "localhost"):
        print("ERROR: Built-in server must bind to loopback for this phase.")
        raise SystemExit(1)
    print(f"GLOBALCOIN node listening on http://{HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), GlobalCoinHandler).serve_forever()
