"""GLOBALCOIN Phase 2: authenticated peer management and safe chain sync.

This module uses only the Python standard library and the existing blockchain.py
and storage.py interfaces. It never sends or requests wallet private keys.
"""
from __future__ import annotations

import ipaddress
import json
import os
import socket
import time
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from blockchain import Blockchain, VERSION
from storage import save_blockchain

MAX_RESPONSE_BYTES = 5_000_000
REQUEST_TIMEOUT = 5


class PeerError(ValueError):
    pass


def normalize_peer_url(value: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise PeerError("Peer URL is required")
    value = value.strip().rstrip("/")
    parts = urlsplit(value)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise PeerError("Peer URL must start with http:// or https://")
    if parts.username or parts.password or parts.query or parts.fragment:
        raise PeerError("Credentials, query strings and fragments are not allowed")
    if parts.path not in ("", "/"):
        raise PeerError("Peer URL must contain only scheme, host and optional port")

    host = parts.hostname.lower()
    local_names = {"localhost"}
    is_local = host in local_names
    try:
        ip = ipaddress.ip_address(host)
        is_local = ip.is_loopback
        if not (ip.is_global or ip.is_loopback):
            raise PeerError("Private, reserved and non-public IP addresses are blocked")
    except ValueError:
        if host not in local_names:
            # DNS names are allowed only over TLS. DNS is checked before use.
            if parts.scheme != "https":
                raise PeerError("Non-local peers must use HTTPS")
            try:
                answers = socket.getaddrinfo(host, parts.port or 443, type=socket.SOCK_STREAM)
            except OSError as exc:
                raise PeerError("Peer hostname could not be resolved") from exc
            if not answers:
                raise PeerError("Peer hostname has no address")
            for answer in answers:
                address = ipaddress.ip_address(answer[4][0])
                if not address.is_global:
                    raise PeerError("Peer hostname resolves to a non-public address")
    if not is_local and parts.scheme != "https":
        raise PeerError("Remote peers must use HTTPS")
    netloc = parts.netloc.lower()
    return urlunsplit((parts.scheme, netloc, "", "", ""))


class PeerManager:
    def __init__(self, blockchain, chain_file="globalcoin_chain.json",
                 auth_token=None, max_peers=50):
        self.blockchain = blockchain
        self.chain_file = chain_file
        self.auth_token = auth_token or os.environ.get("GLOBALCOIN_NODE_TOKEN", "")
        self.max_peers = max_peers
        self.peers = {}

    def register_peer(self, url):
        normalized = normalize_peer_url(url)
        if normalized not in self.peers and len(self.peers) >= self.max_peers:
            raise PeerError("Peer limit reached")
        self.peers[normalized] = {
            "url": normalized,
            "added_at": int(time.time()),
            "last_seen": None,
            "status": "registered",
        }
        return dict(self.peers[normalized])

    def list_peers(self):
        return [dict(peer) for peer in self.peers.values()]

    def _headers(self):
        headers = {"Accept": "application/json"}
        if self.auth_token:
            headers["Authorization"] = "Bearer " + self.auth_token
        return headers

    def _request_json(self, url, method="GET", payload=None):
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        headers = self._headers()
        if data is not None:
            headers["Content-Type"] = "application/json"
        request = Request(url, data=data, headers=headers, method=method)
        try:
            with urlopen(request, timeout=REQUEST_TIMEOUT) as response:
                raw = response.read(MAX_RESPONSE_BYTES + 1)
                if len(raw) > MAX_RESPONSE_BYTES:
                    raise PeerError("Peer response is too large")
                result = json.loads(raw.decode("utf-8"))
                if not isinstance(result, dict):
                    raise PeerError("Peer returned invalid JSON")
                return result
        except (HTTPError, URLError, TimeoutError, OSError, UnicodeError,
                json.JSONDecodeError) as exc:
            raise PeerError("Peer network request failed") from exc

    def export_chain(self):
        return {
            "version": VERSION,
            "difficulty": self.blockchain.difficulty,
            "transaction_fee": self.blockchain.transaction_fee,
            "chain": self.blockchain.chain,
        }

    @staticmethod
    def _validated_remote_chain(data):
        if not isinstance(data, dict):
            raise PeerError("Invalid chain response")
        if data.get("version") != VERSION:
            raise PeerError("Peer uses an incompatible blockchain version")
        chain = data.get("chain")
        if not isinstance(chain, list) or not chain:
            raise PeerError("Peer supplied an empty or malformed chain")
        difficulty = data.get("difficulty")
        fee = data.get("transaction_fee")
        if type(difficulty) is not int or type(fee) is not int or fee < 0:
            raise PeerError("Peer supplied invalid consensus settings")
        try:
            candidate = Blockchain(
                difficulty=difficulty,
                initial_balances=chain[0].get("allocations"),
                transaction_fee=fee,
            )
            candidate.chain = chain
            if not candidate.is_chain_valid():
                raise PeerError("Peer chain failed integrity validation")
            return candidate
        except PeerError:
            raise
        except Exception as exc:
            raise PeerError("Peer chain could not be validated") from exc

    def sync_from_peer(self, peer_url):
        normalized = normalize_peer_url(peer_url)
        if normalized not in self.peers:
            raise PeerError("Peer is not registered")
        peer = self.peers[normalized]
        response = self._request_json(normalized + "/peer/chain")
        candidate = self._validated_remote_chain(response)

        local_chain = self.blockchain.chain
        remote_chain = candidate.chain
        if not local_chain or not remote_chain:
            raise PeerError("Local or remote chain is empty")
        if candidate.difficulty != self.blockchain.difficulty:
            raise PeerError("Peer consensus difficulty does not match this node")
        if candidate.transaction_fee != self.blockchain.transaction_fee:
            raise PeerError("Peer transaction fee does not match this node")
        if remote_chain[0].get("hash") != local_chain[0].get("hash"):
            raise PeerError("Peer belongs to a different genesis network")
        if len(remote_chain) <= len(local_chain):
            raise PeerError("Peer chain is not longer; local chain was kept")

        # Validate again immediately before replacing local state.
        if not candidate.is_chain_valid():
            raise PeerError("Peer chain failed final validation")
        # Persist the validated candidate before mutating in-memory state.
        save_blockchain(candidate, self.chain_file)
        self.blockchain.chain = candidate.chain

        # Pending transactions were created against the old chain state.
        # Clearing them is safer than mining transactions that may now be
        # invalid or already spent on the accepted remote chain.
        discarded_pending = len(self.blockchain.pending_transactions)
        self.blockchain.pending_transactions = []

        peer["last_seen"] = int(time.time())
        peer["status"] = "reachable"
        return {
            "accepted": True,
            "blocks": len(candidate.chain),
            "discarded_pending_transactions": discarded_pending,
        }

    def check_peer(self, peer_url):
        normalized = normalize_peer_url(peer_url)
        if normalized not in self.peers:
            raise PeerError("Peer is not registered")
        status = self._request_json(normalized + "/status")
        self.peers[normalized]["last_seen"] = int(time.time())
        self.peers[normalized]["status"] = "reachable"
        return status
