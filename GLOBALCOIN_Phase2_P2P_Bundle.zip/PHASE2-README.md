# GLOBALCOIN — Phase 2 Peer-to-Peer Node

## Included files
- `p2p.py`: peer registration, peer validation and chain synchronization.
- `node.py`: HTTP API, including authenticated `/peers`, `/peer/chain`, and `/sync`.
- `test_p2p.py`: unit tests for peer registration, malformed peers, invalid chains and network errors.

`blockchain.py` and `storage.py` are intentionally not modified.

## Requirements
Python 3.10+ and the existing project dependency:
```
pip install -r requirements.txt
```

## Security setup
Peer endpoints require a node token. Set a long random token before starting the node.

Linux/macOS Codespaces terminal:
```
export GLOBALCOIN_NODE_TOKEN='replace-with-a-long-random-secret'
python node.py
```

Windows PowerShell:
```
$env:GLOBALCOIN_NODE_TOKEN='replace-with-a-long-random-secret'
python node.py
```

The default bind address is `127.0.0.1`. Keep it that way for local testing.
For remote nodes, use HTTPS via a properly configured reverse proxy, firewall,
and separate strong node tokens. Do not expose the built-in HTTP server directly
to the public internet.

## API
All peer-management endpoints require:
`Authorization: Bearer YOUR_NODE_TOKEN`

- `GET /peers` — list registered peers.
- `POST /peers` — register a peer. JSON: `{"url":"https://peer.example"}`
- `GET /peer/chain` — authenticated chain export for another node.
- `POST /sync` — synchronize from a registered peer. JSON: `{"url":"https://peer.example"}`

Existing `/status`, `/chain`, `/pending`, `/balance`, `/mine` endpoints remain.
The legacy `/transaction` endpoint is restricted to loopback clients because it
accepts a private key. Never send private keys to another node.

## Consensus and synchronization rules
A remote chain is accepted only if:
1. Its software version and consensus parameters are compatible.
2. Its entire chain passes `Blockchain.is_chain_valid()`.
3. Its genesis hash matches the local network.
4. It is strictly longer than the local chain.

A shorter, equal-length, invalid, or different-genesis chain is rejected.
This MVP uses longest-valid-chain selection; that is not a complete production
consensus protocol and is not Sybil-resistant. Use trusted peers only.

## Tests
```
python -m unittest -v test_p2p.py
```

Run the existing blockchain tests as well:
```
python -m unittest -v test_blockchain.py
```

## Important limitation
This phase implements peer registration and safe chain synchronization. It does
not yet broadcast signed transactions between peers. Transaction propagation
needs a dedicated signed-transaction acceptance method in the blockchain layer;
the private-key-based legacy endpoint must not be reused for peer-to-peer traffic.
