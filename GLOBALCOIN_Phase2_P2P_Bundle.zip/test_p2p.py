import unittest
from unittest.mock import patch

from blockchain import Blockchain
from p2p import PeerManager, PeerError, normalize_peer_url


class PeerManagerTests(unittest.TestCase):
    def setUp(self):
        self.chain = Blockchain(difficulty=1, initial_balances={}, transaction_fee=1)
        self.manager = PeerManager(self.chain, chain_file="unused.json", auth_token="test-token")

    def test_register_and_list_peer(self):
        peer = self.manager.register_peer("http://127.0.0.1:8001")
        self.assertEqual(peer["url"], "http://127.0.0.1:8001")
        self.assertEqual(len(self.manager.list_peers()), 1)

    def test_reject_plain_http_remote_peer(self):
        with self.assertRaises(PeerError):
            normalize_peer_url("http://example.com:8000")

    def test_reject_private_ip(self):
        with self.assertRaises(PeerError):
            normalize_peer_url("http://192.168.1.10:8000")

    def test_reject_malformed_url(self):
        with self.assertRaises(PeerError):
            normalize_peer_url("not-a-url")

    def test_reject_unknown_peer_for_sync(self):
        with self.assertRaises(PeerError):
            self.manager.sync_from_peer("http://127.0.0.1:8001")

    def test_validate_remote_chain(self):
        payload = self.manager.export_chain()
        candidate = self.manager._validated_remote_chain(payload)
        self.assertTrue(candidate.is_chain_valid())

    def test_reject_wrong_version(self):
        payload = self.manager.export_chain()
        payload["version"] = "wrong"
        with self.assertRaises(PeerError):
            self.manager._validated_remote_chain(payload)

    def test_reject_tampered_chain(self):
        payload = self.manager.export_chain()
        payload["chain"][0]["nonce"] = 12345
        with self.assertRaises(PeerError):
            self.manager._validated_remote_chain(payload)

    def test_reject_invalid_consensus(self):
        payload = self.manager.export_chain()
        payload["difficulty"] = "easy"
        with self.assertRaises(PeerError):
            self.manager._validated_remote_chain(payload)

    @patch("p2p.urlopen", side_effect=OSError("network down"))
    def test_network_error_is_safe(self, _mock):
        self.manager.register_peer("http://127.0.0.1:8001")
        with self.assertRaises(PeerError):
            self.manager.check_peer("http://127.0.0.1:8001")


if __name__ == "__main__":
    unittest.main()
